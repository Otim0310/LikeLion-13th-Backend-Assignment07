package com.likelion.basecode.tag.api.dto.request;

public record TagUpdateRequestDto (
        String name
){
}
