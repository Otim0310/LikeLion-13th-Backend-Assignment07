package com.likelion.basecode.member.domain;

public enum Part {
    BACKEND,
    FRONTEND,
    AI
}
