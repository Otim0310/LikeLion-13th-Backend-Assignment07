package com.likelion.basecode.member.api.dto.request;

public record MemberUpdateRequestDto(
        String name,
        int age
) {
}
