package com.likelion.basecode.post.api.dto.request;

public record PostUpdateRequestDto(
        String title,
        String contents
) {
}
