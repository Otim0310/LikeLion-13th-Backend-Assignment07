package com.likelion.basecode.tag.api.dto.request;

public record TagSaveRequestDto(
        String name
) {
}
